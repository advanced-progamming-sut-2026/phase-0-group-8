package view;

import model.User;

public class LeaderboardMenu {
    public void handle(String command) {
    }

    private void show(String sortColumn, boolean asc) {
    }

    private String formatRow(User user) {
        return null;
    }
}