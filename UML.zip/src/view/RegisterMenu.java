package view;

public class RegisterMenu {
    public void handle(String cmd) {}
    private void register(String username, String password, String email,
                          String nickname, String gender, String question, String answer) {}
    private void pickQuestion(int id, String answer, String confirm) {}
    private String validateUsername(String username) {}
    private String validatePassword(String password) {}
    private String validateEmail(String email) {}
    private String validateNickname(String nickname) {}
}
