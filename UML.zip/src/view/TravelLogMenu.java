package view;

import model.Quest;

import java.util.List;

public class TravelLogMenu {
    private static final List<Quest> allQuests = null;

    public void handle(String command) {
    }

    private void showPage(String pageName) {
    }

    private void claimQuest(String id) {
    }
}