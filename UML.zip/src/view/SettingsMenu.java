package view;

public class SettingsMenu {
    public void handle(String cmd) {}
    private void changeDifficulty(int level) {}
}
