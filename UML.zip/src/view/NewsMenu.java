package view;

public class NewsMenu {
    public void run(String cmd) {}
    private void showUnread() {}
    private void showAll() {}
}
