package view;

public class LoginMenu {
    public void handle(String cmd) {}
    private void login(String username, String password) {}
    private void forgetPassword(String user, String answer) {}
    private void checkAnswer(String answer) {}
    private void setNewPassword(String username, String newPassword) {}
}
