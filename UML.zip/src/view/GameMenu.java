package view;

public class GameMenu {
    public void handle(String cmd) {}
    private void enterChapter(String chapter) {}
    private void openGreenhouse() {}
    private void openTravelLog() {}
    private void openLeaderboard() {}
    private void showCoinWallet() {}
    private void showGemWallet() {}
    private void cheatAddCurrency(String amount, String type) {}
}
