package view;

public class ProfileMenu {
    public void handle(String cmd) {}
    private void chaneUsername(String newUsername) {}
    private void changeNickname(String newNickname) {}
    private void changeEmail(String newEmail) {}
    private void changePassword(String oldPassword, String newPassword) {}
    private void showInfo() {}
}
