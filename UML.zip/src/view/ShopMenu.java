package view;

import model.ShopItem;
import model.enums.PlantType;

public class ShopMenu {
    private String dailyRefreshDate;


    public void handle(String command) {
    }

    private void listPermanentItems() {
    }

    private void listDailyItems() {
    }

    private void buyItem(String id, int count, PlantType type) {
    }

    private void refreshDailyIfNeeded() {
    }


}