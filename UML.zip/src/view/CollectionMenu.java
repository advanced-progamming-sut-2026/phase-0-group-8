package view;

public class CollectionMenu {
    public void handle(String cmd) {}
    private void showPlants() {}
    private void showAllPlants() {}
    private void showZombies() {}
    private void showAllZombies() {}
    private void showPlant(String name) {}
    private void showZombie(String name) {}
    private void upgradePlant(String name) {}
    private void purchasePlant(String name) {}
}
