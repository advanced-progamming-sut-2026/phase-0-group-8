package view;

import model.GreenHousePot;

public class GreenHouseMenu {
    private GreenHousePot[][] pots;

    public void handle(String command) {
    }

    private void showGreenhouse() {
    }

    private void plantPot(int x, int y) {
    }

    private void collect(int x, int y) {
    }

    private void speedGrow(int x, int y) {
    }

    private void enterShop() {
    }
}