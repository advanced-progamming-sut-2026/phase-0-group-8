package controller.util;

public class Validator {
    public static boolean isValidUsername(String username) {
        return false;
    }

    public static String isStrongPassword(String password) {
        return null;
    }

    public static boolean isValidEmail(String email) {
        return false;
    }

    public static boolean isValidNickname(String nickname) {
        return false;
    }

    public static String hashSha256(String input) {
        return null;
    }
}