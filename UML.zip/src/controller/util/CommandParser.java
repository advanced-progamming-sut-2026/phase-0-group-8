package controller.util;

import java.util.Map;

public class CommandParser {
    public static Map<String, String> parse(String raw) {
        return null;
    }

    public static String getFlag(Map<String, String> map, String flag) {
        return null;
    }

    public static int getIntFlag(Map<String, String> map, String flag, int defaultValue) {
        return 0;
    }
}