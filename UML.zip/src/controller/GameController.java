package controller;

import model.Board;
import model.User;
import model.enums.PlantType;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class GameController {
    private Board board;
    private User currentUser;
    private List<PlantType> selectedPlants;
    private Set<PlantType> boostedPlants ;
    private Map<PlantType, Integer> plantCooldowns;
    private int difficulty;

    public void startGame(String chapterName) {}
    public void handleCommand(String command) {}
    public void selectPlant(PlantType plant) {}
    public void removePlantSelection(PlantType plant) {}
    public void boostPlant(PlantType plant) {}
}
