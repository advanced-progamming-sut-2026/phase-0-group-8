package controller;

import model.enums.MenuState;

import java.util.Scanner;

public class MenuController {
    private MenuState currentState;
    private Scanner scanner = new Scanner(System.in);
    private GameController gameController;

    public void run() {}
    private void handleCommand(String cmd) {}
    private void enterMenu(String name) {}
    private void exitMenu() {}
    private void showCurrentMenu() {}
    private void logout() {}
}
