package minigame;

import model.Tile;

public class VasebreakerGame {
    private Tile[][] vases;
    private int sunAmount;
    private boolean isOver;

    public void handle(String command) {
    }

    public void breakVase(int r, int c) {
    }

    public void collectSeedPacket(int r, int c) {
    }

    private void checkWin() {
    }
}