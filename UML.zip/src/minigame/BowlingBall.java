package minigame;

import model.Board;
import model.Zombie;
import model.enums.PlantType;

public class BowlingBall {
    private final PlantType type = null;
    private double x;
    private int lane;
    private int direction;

    public void tick(Board board) {
    }

    public void onHitZombie(Zombie zombie) {
    }
}