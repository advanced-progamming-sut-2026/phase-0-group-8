package minigame;

import model.enums.PlantType;

public class BeghouledGame {
    private PlantType[][] grid;
    private int sunAmount;
    private int matchesMade;
    private final int targetMatches = 0;
    private boolean[][] craterTiles;

    public void handle(String command) {
    }

    public void swapPlants(int r1, int c1, int r2, int c2) {
    }

    public void tick() {
    }

    private void findAndRemoveMatches() {
    }

    private void dropPlants() {
    }

    private void checkWin() {
    }

    public void upgrade(PlantType from, PlantType to) {
    }
}