package minigame;

import model.Zombie;
import model.enums.ZombieType;

import java.util.List;

public class IZombieGame {
    private List<ZombieType> availableZombies;
    private int sunAmount;
    private List<Zombie> sunProducerZombies;
    private int brainsEaten;
    private boolean isOver;

    public void handle(String command) {
    }

    public void placeZombie(ZombieType type, int r, int c) {
    }

    public void tick() {
    }

    private void checkWin() {
    }

    private void checkLoss() {
    }
}
