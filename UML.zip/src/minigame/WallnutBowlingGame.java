package minigame;

import model.enums.PlantType;

import java.util.List;
import java.util.Queue;

public class WallnutBowlingGame {
    private Queue<PlantType> conveyorPlants;
    private List<BowlingBall> bowlingBalls;
    private int sunAmount;
    private final int redLineColumn = 0;

    public void handle(String command) {
    }

    public void plantBall(PlantType type, int r, int c) {
    }

    public void tick() {
    }

    private void checkWin() {
    }
}