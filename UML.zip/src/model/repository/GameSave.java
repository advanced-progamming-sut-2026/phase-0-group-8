public class GameSave {
    private static final String FILE_PATH = "savegame.json";

    public static void save(User user, Board board) {
    }

    public static Board load(String username) {
        return null;
    }

    public static void deleteSave(String username) {
    }
}