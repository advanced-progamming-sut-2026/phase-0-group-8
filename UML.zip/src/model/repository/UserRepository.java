package model.repository;

import model.User;

import java.util.HashMap;
import java.util.Map;

public class UserRepository {
    private static final String FILE_PATH = "users.json";
    private static Map<String, User> users = new HashMap<>();
    private static User loggedInUser = null;


    public static void loadAll() {

    }

    public static void saveAll() {

    }

    public static Map<String, User> getAllUsers() {

    }

    public static User getLoggedInUser() {
        return loggedInUser;
    }

    public static User findUserByName(String username) {

    }
}
