package model;

public class Quest {
    private final String id = null;
    private final String category = null;
    private final String description = null;
    private final int targetValue = 0;
    private final int rewardCoins = 0;
    private final int rewardDiamonds = 0;
    private final int rewardSeedPackets = 0;
    private final boolean isDaily = false;
    private final int priority = 0;

    public boolean isCompleted(User user) {
        return false;
    }

    public void claim(User user) {
    }

    public String getProgressText(User user) {
        return null;
    }
}