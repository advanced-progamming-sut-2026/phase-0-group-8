package model;

import model.def.ZombieDef;
import model.enums.ChapterType;
import model.enums.ZombieType;

import java.util.List;

public class WaveManager {
    private final ChapterType chapter;
    private final int difficulty;
    private final int baseWaveCost;

    public int getWaveCost(int waveNumber){}
    public List<ZombieDef> buildWave(int waveCost){}
    private List<ZombieType> getZombiesForChapter(){}
}
