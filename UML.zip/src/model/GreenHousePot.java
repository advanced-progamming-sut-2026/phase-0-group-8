package model;

import model.enums.PlantType;

public class GreenHousePot {
    private final int x = 0;
    private final int y = 0;
    private boolean isLocked;
    private PlantType plantType;
    private long plantedAt;
    private boolean isMarigold;
    private double growthHours;

    public boolean isReadyToCollect() {
        return false;
    }

    public void collect(User user) {
    }

    public void speedGrow(User user) {
    }

    public double hoursRemaining() {
        return 0.0;
    }

    public void unlock(User user) {
    }
}