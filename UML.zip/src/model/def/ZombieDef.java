package model.def;

import model.enums.ArmorType;
import model.enums.BehaviorType;
import model.enums.ZombieType;

import java.util.List;

public class ZombieDef {
    private final ZombieType type;
    private final String displayName;
    private final String chapter;
    private final int maxHp;
    private final int damage;
    private final int waveCost;
    private final double speed;
    private final List<ArmorType> armorLayers;
    private final List<BehaviorType> behaviors;

    public ZombieType getType() { return type; }
    public int getMaxHp() { return maxHp; }
    public double getSpeed() { return speed; }
    public int getDamage() { return damage; }
    public int getWaveCost() { return waveCost; }
    public boolean hasBehavior(BehaviorType bt) { return behaviors.contains(bt); }
    public List<ArmorType> getArmorLayers() { return armorLayers; }
    public List<BehaviorType> getBehaviors() { return behaviors; }

}
