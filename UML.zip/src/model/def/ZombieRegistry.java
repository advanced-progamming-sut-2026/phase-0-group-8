package model.def;

import model.enums.ZombieType;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ZombieRegistry {
    private static final Map<ZombieType, ZombieDef> ALL = new HashMap<>();

    public static ZombieDef get(ZombieType type) { return ALL.get(type); }
    public static Map<ZombieType, ZombieDef> getAll() { return Collections.unmodifiableMap(ALL); }
    public static List<ZombieDef> getForChapter(String chapter) {return null;}
}
