package model.def;

import model.enums.BehaviorType;
import model.enums.PlantType;
import model.enums.Tag;

import java.util.List;
import java.util.Set;

public class PlantDef {

    private final PlantType type;
    private final String displayName;
    private final int sunCost;
    private final int maxHp;
    private final int rechargeSeconds;
    private final int damage;
    private final int range;
    private final Set<Tag> tags;
    private final List<BehaviorType> behaviors;
    private final int seedPacketsToUpgrade;
    private final int coinsToUpgrade;
    private final boolean canStackOn;
    private final boolean canPlantOnWater;


    public PlantType getType() { return type; }
    public int getSunCost() { return sunCost; }
    public boolean hasTag(Tag tag) { return tags.contains(tag); }
    public boolean hasBehavior(BehaviorType bt) { return behaviors.contains(bt); }
    public int[] getUpgradeCost(int level) {return null;}
}
