package model.def;

import model.enums.PlantType;

import java.util.Collection;
import java.util.Map;

public class PlantRegistry {
    private static final Map<PlantType, PlantDef> ALL;

    public static PlantDef get(PlantType type) { return ALL.get(type); }
    public static void loadFromCsv(String path) {}
    public static Collection<PlantDef> getAll() { return ALL.values(); }
}
