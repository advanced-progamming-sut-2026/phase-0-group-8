package model;

import model.def.ZombieDef;
import model.enums.ArmorType;

import java.util.*;

public class Zombie {
    private final ZombieDef def;
    private int currentHp;
    private double x;
    private int lane;
    private List<Armor> armors = new ArrayList<>();
    private boolean isAlive = true;
    private boolean isGlowing;
    private int ticksSinceSpawn;
    private boolean hasThrownImp;
    private int stolenSun;
    private boolean torchLit;
    private boolean newspaperDestroyed;
    private Map<String, Integer> activeEffects = new HashMap<>();
    private int frozenTurns = 0;
    private double chillFactor = 1.0;
    private boolean isHypnotized;

    public void tick(Board board) {  }
    public void takeDamage(int dmg, boolean isPoisonDamage) {}
    public boolean isAlive() { return isAlive; }
    public double getX() { return x; }
    public int getLane() { return lane; }
    public ZombieDef getDef() { return def; }
    public List<Armor> getArmors() { return armors; }
    public void applyEffect(String effect, int ticks) { activeEffects.put(effect, ticks); }
    public boolean isSlowed() { return chillFactor < 1.0; }
    public boolean isFrozen() { return frozenTurns > 0; }
    private void runBehaviors(Board board) { }
    private void tryMove(Board board) { }
    private void onArmorDestroyed(ArmorType type) {}
    private void die(Board board) { isAlive = false;}
}
