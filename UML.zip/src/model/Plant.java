package model;

import model.def.PlantDef;

import java.util.HashMap;
import java.util.Map;

public class Plant {
    private final PlantDef def;
    private int currentHp;
    private int x;
    private int lane;
    private int level = 1;
    private boolean isBoosted;
    private int boostTicksRemaining;
    private int sunProductionTimer;
    private boolean isFrozen;
    private int iceLayers = 0;
    private boolean isCat;
    private boolean isOnLilyPad;
    private Plant underPlant;
    private Map<String, Integer> activeEffects;

    public void tick(Board board) {}
    public void takeDamage(int dmg) { currentHp -= dmg; if (currentHp <= 0) destroy(); }
    public void applyPlantFood(Board board) {}
    public void upgrade() {}
    public boolean isAlive() { return currentHp > 0; }
    public boolean canShoot() { return !isFrozen && !isCat; }
    public boolean produceSun() { return sunProductionTimer <= 0; }
    public PlantDef getDef() { return def; }
    public int getCurrentHp() { return currentHp; }
    public void destroy() {}
}
