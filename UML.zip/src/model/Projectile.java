package model;

import model.enums.PlantType;

public class Projectile {
    private final PlantType ownerType;
    private final int damage;
    private final boolean isFireType;
    private final boolean isIceType;
    private final boolean isPoisonType;
    private final boolean isLobber;
    private double x;
    private int lane;
    private boolean isAlive;

    public void tick(Board board) {}
    public void hitZombie(Zombie z) {}
    public boolean isAlive() { return isAlive; }
}
