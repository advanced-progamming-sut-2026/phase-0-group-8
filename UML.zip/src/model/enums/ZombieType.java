package model.enums;

public enum ZombieType {
    NORMAL,
    CONEHEAD,
    BUCKETHEAD,
    KNIGHT,
    BLOCKHEAD,
    GARGANTUAR,
    IMP,
    ALL_STAR,
    ARCADE,
    PARASOL,
    TURQUOISE,
    PROSPECTOR,
    PIANIST,
    NEWSPAPER,
    BARREL_ROLLER,
    RA_ZOMBIE,
    EXPLORER,
    TOMBRAISER,
    DODO_RIDER,
    HUNTER,
    TROGLOBITE,
    FISHERMAN,
    SNORKEL,
    OCTOPUS,
    JESTER,
    WIZARD,
    KING,
    DRAGON_IMP;

}
