package model;

import model.enums.TileType;

public class Tile {
    private TileType type;
    private Plant plant;
    private int gravestoneHp;
    private boolean isIcyGround;
    private int slipDirection;
    private boolean hasNecromancy;
    private boolean isUnderwater;

    public boolean plantHere(Plant p) {
    }

    public Plant removePlant() {
    }

    public Plant getPlant() {
    }

    public boolean isEmpty() {
    }

    public boolean isPlantable() {
    }

    public void hitGrave(int damage) {
    }

    public TileType getType() {
    }

}
