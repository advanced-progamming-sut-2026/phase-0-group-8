package model;

import model.enums.ChapterType;
import model.enums.PlantType;
import model.enums.SpecialLevelType;
import model.enums.ZombieType;

import java.util.ArrayList;
import java.util.List;

public class Board {
    private Tile[][] tiles ;
    private List<Zombie> zombies;
    private List<Projectile> projectiles;
    private List<Sun> suns ;
    private boolean[] lawnMowers;
    private int sunAmount;
    private int currentWave;
    private int totalWaves;
    private boolean[] waveStarted;
    private int plantFoodCount;
    private int tickCount;
    private ChapterType chapter;
    private int difficulty;
    private int waterLevel;
    private boolean isGameOver;
    private boolean playerWon;
    private SpecialLevelType specialLevelType;
    private List<int[]> savedPlants;
    private int deadlineColumn = -1;
    private int plantLossCount;
    private int conveyorTimer;
    private int initialSunForPWYG;
    private int timedWarTarget;

    public void advanceTime(int ticks) {}
    public boolean plantPlant(PlantType type, int col, int row){}
    public boolean pluckPlant(int col, int row) {}
    public boolean collectSun(int col, int row) {}
    public boolean collectFallingSun(int col, int lane) {}
    public boolean feedPlant(int col, int row) {}
    public void showMap() {}
    public void showPlantsStatus() {}
    public void showTileStatus(int col, int row) { }
    public void showSunAmount() { }
    public void showZombiesInfo() { }
    public void cheatAddSuns(int amount) {}
    public void cheatRemoveCooldown() { }
    public void cheatReleaseNuke() {}
    public void cheatSpawnZombie(ZombieType type, int lane, int x) {}
    public void spawnZombie(ZombieType type, int lane, int x) {}
    public int stealSun(int amount) {}
    public void burnPlantInFrontOf(Zombie z) { }
    public void throwIceAt(Zombie z) { }
    public Plant getPlantInFrontOf(Zombie z) {}
    private void triggerLawnMower(int lane) { }
    private void dropSunFromSky() {}
    private void checkWaveAdvance() { }
    private void spawnWave(int waveNum) {}
    private void checkWinLoss() { }
}
