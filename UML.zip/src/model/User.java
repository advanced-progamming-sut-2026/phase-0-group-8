package model;

import model.enums.Gender;
import model.enums.PlantType;
import model.enums.ZombieType;

import java.util.*;

public class User {
    private String username;
    private String passwordHash;
    private String nickname;
    private String email;
    private Gender gender;
    private String securityQuestion;
    private String securityAnswerHash;
    private int coins;
    private int diamonds;
    private int gamesPlayed;
    private int levelsCompleted;
    private int bestScoreMode;
    private List<PlantType> unlockedPlants;
    private List<ZombieType> seenZombies;
    private boolean stayLoggedIn;
    private List<String> unreadNews;
    private List<String> allNews;
    private Map<String, Integer> questProgress;
    private String dailyQuestLastDate;
    private String dailyShopLastDate;
    private Map<PlantType, Integer> plantSeedPacket;
    private Map<PlantType, Integer> plantLevels;
    private Map<PlantType, Boolean> plantBoosts;
    private Map<String, Integer> minigamesCompleted;

    public User(String username, String passwordHash, String nickname, String email,
                Gender gender, String securityQuestion, String securityAnswerHash) {

    }


    public String getUsername() {
        return username;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public String getNickname() {
        return nickname;
    }

    public String getEmail() {
        return email;
    }

    public Gender getGender() {
        return gender;
    }

    public String getSecurityQuestion() {
        return securityQuestion;
    }

    public String getSecurityAnswerHash() {
        return securityAnswerHash;
    }

    public int getCoins() {
        return coins;
    }

    public int getDiamonds() {
        return diamonds;
    }

    public int getGamesPlayed() {
        return gamesPlayed;
    }

    public int getLevelsCompleted() {
        return levelsCompleted;
    }

    public int getBestScoreMode() {
        return bestScoreMode;
    }

    public List<PlantType> getUnlockedPlants() {
        return unlockedPlants;
    }

    public List<ZombieType> getSeenZombies() {
        return seenZombies;
    }

    public boolean isStayLoggedIn() {
        return stayLoggedIn;
    }

    public List<String> getUnreadNews() {
        return unreadNews;
    }

    public List<String> getAllNews() {
        return allNews;
    }

    public Map<String, Integer> getQuestProgress() {
        return questProgress;
    }

    public String getDailyQuestLastDate() {
        return dailyQuestLastDate;
    }

    public String getDailyShopLastDate() {
        return dailyShopLastDate;
    }

    public Map<PlantType, Integer> getPlantSeedPacket() {
        return plantSeedPacket;
    }

    public Map<PlantType, Integer> getPlantLevels() {
        return plantLevels;
    }

    public Map<PlantType, Boolean> getPlantBoosts() {
        return plantBoosts;
    }

    public Map<String, Integer> getMinigamesCompleted() {
        return minigamesCompleted;
    }

    // SETTERS
    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public void setSecurityQuestion(String securityQuestion) {
        this.securityQuestion = securityQuestion;
    }

    public void setSecurityAnswerHash(String securityAnswerHash) {
        this.securityAnswerHash = securityAnswerHash;
    }

    public void setBestScoreMode(int bestScoreMode) {
        this.bestScoreMode = bestScoreMode;
    }

    public void setStayLoggedIn(boolean stayLoggedIn) {
        this.stayLoggedIn = stayLoggedIn;
    }

    public void setDailyQuestLastDate(String dailyQuestLastDate) {
        this.dailyQuestLastDate = dailyQuestLastDate;
    }

    public void setDailyShopLastDate(String dailyShopLastDate) {
        this.dailyShopLastDate = dailyShopLastDate;
    }

    // LIST METHODS
    public void unlockPlant(PlantType plant) {
        unlockedPlants.add(plant);
    }

    public void seeZombie(ZombieType zombie) {

    }

    public void addToUnreadNews(String news) {

    }

    public void removeFromUnreadNews(String news) {

    }

    public void addToAllNews(String news) {

    }

    public void markAllNewsRead() {

    }

    // CURRENCY METHODS
    public void addCoins(int coins) {

    }

    public void addDiamonds(int diamonds) {

    }

    public void spendCoins(int coins) {

    }

    public void spendDiamonds(int diamonds) {

    }
}
