package model;

import model.enums.ArmorType;

import java.util.Map;

public class Armor {
    private final ArmorType type;
    private int currentHp;

    private static final Map<ArmorType, Integer> MAX_HP;

    public void takeDamage(int dmg) { currentHp -= dmg; }
    public boolean isDestroyed() { return currentHp <= 0; }
    public ArmorType getType() { return type; }
    public int getCurrentHp() { return currentHp; }
    public static int getMaxHp(ArmorType type) { return MAX_HP.getOrDefault(type, 0); }
}
