package model;

import model.enums.SunType;

public class Sun {
    private final SunType type;
    private int x;
    private int lane;
    private int ticksFalling;
    private boolean isOnGround ;
    private boolean collectedByPlayer;
    private boolean producedByPlant;

    public void tick(){};
    public int getValue(){};
    public boolean isCollectable(){};
    public void explodeIfRadioactive(){};
}
