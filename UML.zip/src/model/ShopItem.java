package model;

public class ShopItem {
    private final String id = null;
    private final String name = null;
    private final int costCoins = 0;
    private final int costDiamonds = 0;
    private final int quantity = 0;
    private final boolean isDailyItem = false;

    public String getDescription() {
        return null;
    }

    public boolean isPurchasable(){return true;}
}